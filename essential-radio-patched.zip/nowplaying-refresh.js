async function fetchNowPlaying() {
  try {
    const res = await fetch('/api/metadata');
    const data = await res.json();
    document.getElementById('artist').textContent = data.artist || 'Unknown';
    document.getElementById('title').textContent = data.title || '';
  } catch (err) {
    console.error('Failed to fetch metadata', err);
  }
}
setInterval(fetchNowPlaying, 10000);
fetchNowPlaying();