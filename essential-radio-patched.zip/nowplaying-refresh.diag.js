async function fetchNowPlaying() {
  try {
    const res = await fetch('/api/metadata?debug=1');
    const data = await res.json();
    document.getElementById('diagnostic').textContent = JSON.stringify(data, null, 2);
  } catch (err) {
    document.getElementById('diagnostic').textContent = 'Error fetching metadata: ' + err;
  }
}
setInterval(fetchNowPlaying, 5000);
fetchNowPlaying();